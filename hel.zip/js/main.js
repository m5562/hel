const toggler = document.getElementById("toggle");
const sidebar = document.getElementById("sidebar");

toggler.addEventListener("click", () => {
  console.log("hello");
  sidebar.style.left = "0";
});
